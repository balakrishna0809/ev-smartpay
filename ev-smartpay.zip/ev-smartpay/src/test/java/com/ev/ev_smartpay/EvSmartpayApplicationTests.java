package com.ev.ev_smartpay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvSmartpayApplicationTests {

	@Test
	void contextLoads() {
	}

}
