package com.ev.ev_smartpay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvSmartpayApplication {

	public static void main(String[] args) {
		SpringApplication.run(EvSmartpayApplication.class, args);
	}

}
